module.exports = (args) => {
  require('../main/main')(args._[1]);
};
