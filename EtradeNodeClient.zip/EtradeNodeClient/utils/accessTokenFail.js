const accessTokenFail = (error) => {
  console.log(`Access Token Failed -- Error is ${Json.tringify(error)}`);
};

module.exports = accessTokenFail;
